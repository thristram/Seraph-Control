Software Dictionary is  "opt/seraph_esh/apps"

1. run "setup.sh", Follow the instruction to install Node.js
2. run node /opt/seraph_esh/Lib/TCPClient.js
3. Open any web broswer and checkout "http://localhost:200001"

NOTE:

1. In Step 3, localhost may be accessable from other devices such as a mobile phone, use the board's IP Address instead of localhost to access the board.
2. To configurate SS's TCP Address, ports, update MySQL connection info etc. Please run /opt/seraph_esh/install/configurate.sh (or manully change configuration in "/opt/seraph_esh/config.js")


Have Fun, and feel free to ask any questions via Wechat!