#!/bin/sh
echo "";
echo "Updating eSeraph Hub Software.....";
echo "";
echo "---------------------------------------------------------------------------------------------------------------------------"
echo "";




cd /opt/seraph_esh

echo "Entering Seraph eSH Dictionary......";
echo "";
echo "---------------------------------------------------------------------------------------------------------------------------"
echo "";

echo "Checking Software Version......";
echo "";
#formatFunction (100161212);


versionR=$(curl 'http://ha.applicationclick.com/index.php/seraph/eshupdate')
echo "";
echo "Newest Software Version is: $versionR";
echo "";

versionFile="/opt/seraph_esh/version";


update(){
    cd /opt/seraph_esh/update
    updatePackage="/opt/seraph_esh/update/esh_$versionR.zip";
    if [ -f "$updatePackage" ]; then
        echo "";
    else
        packageURL="http://ha.applicationclick.com/static/esh/software/esh_$versionR.zip"
        sudo wget "$packageURL";
    fi
    sudo rm -rf /opt/seraph_esh/apps
    sudo mkdir /opt/seraph_esh/apps
    sudo unzip "esh_$versionR.zip" -d /opt/seraph_esh/apps
    sudo chmod -R 777 /opt/seraph_esh
    cd /opt/seraph_esh/apps/install
    echo "";

    sudo chmod 777 /opt/seraph_esh/apps/install/dependency.sh
    /opt/seraph_esh/apps/install/dependency.sh
    sudo chmod 777 /opt/seraph_esh/apps/install/additionalUpdate.sh
    /opt/seraph_esh/apps/install/additionalUpdate.sh
    sudo chmod 777 /opt/seraph_esh/apps/install/appConfig.sh
    /opt/seraph_esh/apps/install/appConfig.sh

    echo "";
    cd /opt/seraph_esh/
    rm -rf version
    echo "$versionR" >> version

}

cd /opt/seraph_esh
if [ -f "$versionFile" ]; then
    versionNo=$(cat "$versionFile")
    echo "Current eSH Software Version: $versionNo"
    echo "";
    if [ "$versionNo" \<  "$versionR" ]; then
        update
    else
        echo "You have the Latest eSH software....."

    fi


else
	echo "No eSH Software Version Found, Requesting New Software from Seraph Update....."
	update
fi
echo "---------------------------------------------------------------------------------------------------------------------------"
echo "";
echo "Seraph Update Complete! Software Dictoinary is /opt/seraph_esh";
echo "";
echo "run 'node /opt/seraph_esh/apps/Lib/TCPClient.js' to start!";
echo "";
echo "";

cd /opt/seraph_esh/apps
#node /opt/seraph_esh/apps/TCPClient.js

