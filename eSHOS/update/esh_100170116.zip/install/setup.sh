#!/bin/sh
echo "";
echo "";
input="./logo.txt"
currentDictionary=$(pwd)
while IFS= read -r var
do
  echo "$var"
done < "$input"

echo "";
echo "Initializing Installer.....";
echo "";
echo "---------------------------------------------------------------------------------------------------------------------------"
echo "";
while true; do
    read -p "Do you wish to install Node.js [y/n]?  " yn
    case $yn in
        [Yy]* )
			echo "Setting up Node.js.....";
			curl -sL https://deb.nodesource.com/setup_6.x | sudo -E bash -;
			sudo apt-get install -y nodejs;
			sudo apt-get install -y build-essential;
			break;;
        [Nn]* )
            echo "Exiting Node.js installation.....";
            echo "Moving Forward.....";

            break;;
        * ) echo "Please answer yes or no.";;
    esac
done

echo "";
echo "---------------------------------------------------------------------------------------------------------------------------"
echo "";

while true; do
    read -p "Do you wish to install MySQL [y/n]?  " yn
    case $yn in
        [Yy]* ) 
			echo "Setting up MySQL.....";
			sudo apt-get install mysql-server;
			break;;
        [Nn]* )
            echo "Exiting MySQL installation.....";
            echo "Moving Forward.....";
            break;;
        * ) echo "Please answer yes or no.";;
    esac
done

echo "";
echo "---------------------------------------------------------------------------------------------------------------------------"
echo "";


if [ -d "/opt" ]; then
    echo "";
else
    cd /
    echo "Creating Dictionary /opt.....";
    sudo mkdir opt;
fi

cd /opt

if [ -d "/opt/seraph_esh" ]; then
    echo "";
else
    echo "Creating Dictionary /seraph_esh.....";
    sudo mkdir seraph_esh;
    cd seraph_esh
    sudo mkdir update;
    sudo mkdir apps;
fi
sudo chmod -R 777 /opt/seraph_esh


cd "$currentDictionary"
sudo chmod 777 ./configurate.sh
./configurate.sh

echo "Setting up Node.js Modules.....";


cd /opt/seraph_esh

npm install mysql
npm install express --save
npm install --save body-parser
sudo apt-get install unzip

echo "";
echo "---------------------------------------------------------------------------------------------------------------------------"
echo "";

echo "eSeraph Hub OS v1.0.0 Has been Successfully Installed.";


echo "";
echo "---------------------------------------------------------------------------------------------------------------------------"
echo "";

cd "$currentDictionary"
sudo chmod 777 ./update.sh
./update.sh