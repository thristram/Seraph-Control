#!/bin/sh
echo "Configurating eSH Software...."
echo "";
echo "---------------------------------------------------------------------------------------------------------------------------"
echo "";

read -p "Please enter MySQL username           : " username
read -p "Please enter MySQL password           : " password
read -p "Please enter SS's TCPAddress          : " TCPAddress
read -p "Please enter SS's TCPort (eg. 1833)   : " TCPort
read -p "Please enter SS's HTTPort (eg. 80)    : " HTTPort


cd /opt/seraph_esh
rm -rf ./config.js
echo "module.exports = { \n
    HTTPort : $HTTPort, \n
    TCPort : $TCPort,\n
    UDPort : 20000,\n
    SSPushPort : 200002,\n
    versionNumber : 1,\n
    TCPAddress : '$TCPAddress',\n
    SQLConfig : {\n
        host : 'localhost',\n
        username: '$username',\n
        password: '$password',\n
        defaultDB: 'seraph',\n
    }\n
}" >> config.js

echo "";
echo "---------------------------------------------------------------------------------------------------------------------------"
echo "";