#!/bin/sh
echo "Installing dependencies...."
npm install mustache --save
npm i mustache-express
npm install raspi-llio